package com.product.blinkit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlinkitApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlinkitApplication.class, args);
	}

}

