package com.product.blinkit.controller;

import com.product.blinkit.model.Product;
//import com.product.catalog.service.Service;
import com.product.blinkit.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private ProductService proService;

    @GetMapping("/product")
    private ResponseEntity<List<Product>> getAllProduct(){
        return ResponseEntity.ok().body(this.proService.getProducts());
    }
    @GetMapping("/product/{productid}")
    private Product getProductById(@PathVariable long productid){
        return this.proService.getProduct(productid);
    }

    @PostMapping("/products")
    private ResponseEntity<Product> saveProduct(@RequestBody Product product){
        return ResponseEntity.ok().body(this.proService.createProduct(product));
    }
    @PutMapping("/products/{productid}")
    private ResponseEntity<Product> updateProduct(@PathVariable long productid, @RequestBody Product prodt) {
        prodt.setProduct(productid);
        return ResponseEntity.ok().body(this.proService.updateProduct(prodt));
    }
    @DeleteMapping("/product/{productid}")
    private HttpStatus deleteProduct(@PathVariable long productid){
        this.proService.deleteProduct(productid);
        return HttpStatus.OK;
    }
}
