package com.product.blinkit.service;

import com.product.blinkit.exception.ProductException;
import com.product.blinkit.model.Product;
import com.product.blinkit.repository.Productrepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ProductImp implements ProductService{
    @Autowired
    private Productrepository productrepository;
    @Override
    public Product createProduct(Product Pr) {
        return this.productrepository.save(Pr);

    }

    @Override
    public List<Product> getProducts() {
        return this.productrepository.findAll();
    }

    @Override
    public Product updateProduct(Product Pr) {
        Optional<Product> proobj = this.productrepository.findById(Pr.getProductid());
        if (proobj.isPresent()) {
            Product productUpdate = proobj.get();
            productUpdate.setProduct(Pr.getProductid());
            productUpdate.setProduct_name(Pr.getProduct_name());
            productUpdate.setPrice(Pr.getPrice());
            return this.productrepository.save(productUpdate);
        }
        else{
            throw new ProductException("Error");
        }
    }

    @Override
    public Product getProduct(long id) {
        return this.productrepository.findById(id).get();
    }

    @Override
    public void deleteProduct(long id) {
       this.productrepository.deleteById(id);
    }
}
