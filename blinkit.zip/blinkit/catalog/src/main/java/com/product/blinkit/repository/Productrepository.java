package com.product.blinkit.repository;

import com.product.blinkit.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Productrepository extends JpaRepository<Product,Long> {
}
