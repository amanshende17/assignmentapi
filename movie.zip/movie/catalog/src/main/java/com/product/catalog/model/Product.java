package com.product.catalog.model;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.util.Date;

@Entity
@Table(name="products")
public class Product {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long productid;
    @Column (name="product_name")
    private String product_name;
    @Column (name="price")
    private long price;
    @CreationTimestamp
    private Date createdTime;

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public long getPrice() {
        return price;
    }

    public void setPrice(long price) {
        this.price = price;
    }

    public long getProductid() {
        return productid;
    }

    public void setProduct(long productid) {
        this.productid = productid;
    }
}
