package com.product.catalog.controller;

import com.product.catalog.exception.ProductException;
import com.product.catalog.model.Product;
//import com.product.catalog.service.Service;
import com.product.catalog.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpStatusCodeException;

import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private ProductService proService;

    public long start_money = 1000;

    @GetMapping("/product")
    private ResponseEntity<List<Product>> getAllProduct(){
        return ResponseEntity.ok().body(this.proService.getProducts());
    }
    @GetMapping("/product/{productid}")
    private Product getProductById(@PathVariable long productid,@RequestBody Product prod){
        long y = prod.getPrice();
        if(start_money >= y)
        {
            start_money = start_money - y;
        }
        else{
            throw new ProductException("InsufficientBalance");
        }
        return this.proService.getProduct(productid);
    }

    @PostMapping("/products")
    private ResponseEntity<Product> saveProduct(@RequestBody Product product){
        return ResponseEntity.ok().body(this.proService.createProduct(product));
    }
    @PutMapping("/products/{productid}")
    private ResponseEntity<Product> updateProduct(@PathVariable long productid, @RequestBody Product prodt) {
        prodt.setProduct(productid);
        return ResponseEntity.ok().body(this.proService.updateProduct(prodt));
    }
    @DeleteMapping("/product/{productid}")
    private HttpStatus deleteProduct(@PathVariable long productid){
        this.proService.deleteProduct(productid);
        return HttpStatus.OK;
    }
}
