package com.product.catalog.repository;

import com.product.catalog.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Productrepository extends JpaRepository<Product,Long> {
}
