package com.product.catalog.service;
import com.product.catalog.model.Product;

import java.util.List;
public interface ProductService {
    Product createProduct(Product Pr);
    Product updateProduct(Product Pr);

    List<Product> getProducts();
    Product getProduct(long id);
    void deleteProduct(long id);



}
